Informationen zur Installation von Libraries finden sich unter: http://arduino.cc/en/Guide/Libraries
